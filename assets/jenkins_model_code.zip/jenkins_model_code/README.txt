README
Modeling the effects of a partner on the spatial compatibility effect
By AJ Jenkins

*** What I was modeling:
My model is based on the work done by Sebanz, Knoblich, and Prinz (2003),
which examines the effect of a partner on the spatial compatibility effect.
I discussed their experiment during my presentation, but I will rehash the
part of their experiment that I modeled. Participants were either alone or
with a partner and sat on one side of a computer. The left participant (or
only participant) pressed the left key as soon as they saw the red stimulus.
The right participant pressed the right key as soon as they saw the green
stimulus. There was also an irrelevant spatial stimulus in the form of a
finger that always either pointed towards the correct button/participant 
(spatially compatible) or away from it (spatially incompatible). Other
conditions were also tested, but I only modeled this part of the experiment.
Citation for paper at bottom.
Relevant results below:

RT for conditions (in msec) -

             | Joint | Individual
Compatible   |  325  |    323
Incompatible |  336  |    326

*** Running my model:
1. Put folder contents into pdptool folder
2. Run the file "go6_run.m"
3. Set the following options:
 - min = 0
 - rest = 0
 - ncycles = 100
 - decay = 0.001
 - Use defaults for other options
4. Check the box for Pat
5. Select a pattern from the Patterns window. Patterns are:
 p1 = my color, compatible, partner
 p2 = my color, compatible, no partner
 p3 = my color, incompatible, partner
 p4 = my color, incompatible, no partner
 p5 = other color, compatible, partner
 p6 = other color, compatible, no partner
 p7 = other color, incompatible, partner
 p8 = other color, incompatible, no partner
Note: since error rate was ~1%, model does not account for error, so
model was only tested with p1-p4. However, p5-8 should be below threshold.
6. Step through until output activation (press_button) is at least 0.90
7. Number of cycles is shown in the bottom right corner.
*Note: Annotated version of model is attached (jenkins_annotated.pdf).

*** Evaluation of my model:
Results from model below:

Number of update cycles for output activation (press_button) to exceed 0.90
             | Joint | Individual
Compatible   |  31   |    32
Incompatible |  34   |    33

Like the original data, my data shows the same interaction effect between
spatial compatibility and presence of a partner. However, if you scale my
data so that it maps to the experimental data (1 cycle = 10.5 msec), then
you'll see that the effects (mains and interaction) are more extreme than
the original data. Another test I did is what happens if you make the
partner parameter something between 0 and 1 (e.g., 0.5). I did this to 
see if I would get a middle ground effect of spatial compatibility, as
was shown in Experiment 2 of the original study (presence and no feedback
conditions). Using 0.5 for partner activation, I got 32 cycles for
compatible and 33 cycles for incompatible. This is identical to the 
individual condition results, so perhaps an input of 0.5 is kind of like
having someone sitting next to you (presence condition). Overall, I think
my model nicely fits the original data, although it might match it better
if it were scaled back to run in more cycles.

*** Justification of my model:
See attached simplified model (jenkins_simple.pdf).
The model made with PDPtool has an excess of connections, so any connection
that I felt was unnecessary or implausible was set to a weight of 0. My model
is most easily explained through an example, so I'll walk through what happens
if it's your color (i.e., you should press your button), the spatial stimulus
is compatible (it's pointing towards you) and you have a partner -
Since it's your color, the my_color input node is activated with 1.0. And
since it's compatible, the compatible input node is also activated with 1.0.
And since you have a partner, the partner node receives 1.0 (0.0 means no
partner). Since it's your color, the "me" node is strongly activated by the
my_color node (wt. 3.0). And since the stimulus is spatially compatible,
the spatial_comp node is activated. If the stim. was incomp. then the 
spatial_incomp node would be activated. Also, since there is a partner
the activation of spatial_comp is intensified. This is to reflect the original
data showing that a partner intensifies the spatial compatibility effect.
Conversely, if there's a partner but the stimulus is incompatible, then
the spatial_incomp node is activated more strongly, so as to reflect the data.
I.e., if there's a partner and the stim. is incomp., then you'll be even
slower. Next, the spatial_comp activates the "me" node (spatial_incomp. would
inhibit it). This is because, when you have a partner, seeing a spatially
compatible stimulus makes the notion of the stimulus being "for you" stronger
(as can be inferred from the data). Finally, the "me" node activates the 
press_button output node, which is said to exceed its threshold activation
once it's activation is at least 0.90 (this is the activation threshold used
for assignment 1).

About my weights: First I tried to set the weights using backpropagation, but
for some reason, when using PDPtool's backpropagation network type, it always
found it's final output in 1-2 cycles. For this reason, I used an IAC network
and set the weights by hand. 1.0 or -1.0 was used for all weights, except for
the connections between my_color, other_color and "me", which were 3.0 and
-3.0, respectively. These were increased so as to lessen the effects of
spatial compatibility and a partner.

Error was not modeled because error rates in exp. were ~1%. Noise was not
modeled because I was only studying means, and noise would have made it
harder to precisely tune the weights.

*** Advantages/Disadvantages:
The greatest advantages of my model are its simplicity and ability to fit
the data. I don't believe that you could demonstrate the observed effects
with a simpler model. Also, like all connectionist networks, the model has
some biological plausibility because each node operates like a neuron, or
collection of neurons. My model can also be used in interesting ways, like
by altering the input activation of the partner node to simulate different
levels of "partnership" (i.e., no partner, person present, partner w/ no
feedback, or partner w/ feedback). The major disadvantage of my model is that
it doesn't shed much light on the the cognitive processes responsible for
the demonstrated spatial compatibility bias. In reality, there are probably
some intermediary nodes between "partner" and "spatial_comp", but since
these underlying cognitive processes are a complete mystery, I thought it
would be better to omit such nodes.

*** Future work / Improvements:
As mentioned previously, it would be nice if my model data more precisely
mapped to the experimental data, which may be achieved by using less
activation and observing the model over more cycles (>100). Additionally,
my modeling of Experiment 2 wasn't very deep, so it would be interesting
to see the effect of different input activations for the partner node and
see if they can fit the data. It would also be interesting to construct
a model of the two-choice task, although that's essentially what our first
assignment was. One way my model could be improved is by algorithmically
tuning the weights (although I tried to do it with backprop. and it didn't
work, see About my weights).

*** Reference:
    Natalie Sebanz, Günther Knoblich, Wolfgang Prinz
    Representing others' actions: just like one's own?
    Cognition, Volume 88, Issue 3, July 2003, Pages B11–B21
    http://dx.doi.org/10.1016/S0010-0277(03)00043-X