pdp
loadscript ('go6.net');
loadpattern ('file', 'go6.pat', 'setname', 'unary', 'usefor', 'both');
loadtemplate ('go6.tem');
launchnet;
loadweights('go6_best.wt');